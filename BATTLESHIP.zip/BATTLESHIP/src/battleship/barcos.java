/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package battleship;

import javax.swing.JButton;

/**
 *
 * @author ferna
 */
public class barcos extends JButton {
    private String name;
    private int type;
    private String image;
    
    public barcos(String name,int type,String image){
        this.name=name;
        this.type=type;
        this.image=image;
        if(type==5)
            this.image="/barcos/"+image+".png";
        else if(type==4)
            this.image="/barcos/"+image+".png";
        else if(type==3)
            this.image="/barcos/"+image+".png";
        else if(type==2)
            this.image="/barcos/"+image+".png";
    }
}
