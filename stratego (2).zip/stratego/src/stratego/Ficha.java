
package stratego;

import java.awt.Image;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Ficha {
    private String nombre;
    private int rango;
    private boolean esBomba;
    private boolean esTierra;
    private boolean esHeroe;
    private String imagen;

    public Ficha(String nombre,int rango,boolean esBomba,boolean esTierral, boolean esHeroe, String nombreImagen){
        this.nombre=nombre;
        this.rango=rango;
        this.esBomba=esBomba;
        this.esTierra=esTierra;
        this.esHeroe=esHeroe;
        
        if (esHeroe) {
            this.imagen = "/heroes/"+nombreImagen+".png";
        } else if(!esHeroe){
            this.imagen = "/villanos/"+nombreImagen+".png";
        }
    }

    public String getNombre(){
        return nombre;
    }

    public int getRango(){
        return rango;
    }

    public boolean esBomba(){
        return esBomba;
    }

    public boolean esTierra(){
        return esTierra;
    }

    public boolean esHeroe(){
        return esHeroe;
    }
    public void setImagen(Ficha[] fichas,String imagen){
        
        this.imagen=imagen;
    }
    
    
    public String getImagen(){
        return imagen;
    }

    public void mover(){
        System.out.println(nombre+" se ha movido");
    }
    
   

    public boolean PuedeAtacar(Ficha FichaObjetivo){
        if(esBomba&&(rango!=3||FichaObjetivo.getRango()!=3)){
            return false;
        }else if(FichaObjetivo.esBomba()&&rango!=3){
            return false;
        }
        return true;
    }
}
