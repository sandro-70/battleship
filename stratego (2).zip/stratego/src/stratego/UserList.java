/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stratego;

import java.util.ArrayList;

/**
 *
 * @author ferna
 */
public class UserList {
    public static ArrayList<User> users= new ArrayList<>();
}
